//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include <vcl/inifiles.hpp>
#include <stdio.h>
#include <io.h>
#include <fcntl.h>
#include <sys\stat.h>
#include <math.h>

#include "RecognitionPixelGSI.h"
//---------------------------------------------------------------------------
#pragma warn -pck
#pragma option -a1
//---------------------------------------------------------------------------

#pragma package(smart_init)
#pragma resource "*.dfm"
TFormImagePixelPlus *FormImagePixelPlus;

char NameFileInitialPoints[256],NameFileEtalonsGSI[256],
     NameFileRecognitionGSI[256],NameFileText[256],Path[256],
     text[256],CurrentDirectory[256];
FILE *HederProtokol;
int HederFileInitialPoints,HederFileEtalonsGSI,HederFileRecognitionGSI;
bool useFileInitialPoints,useFileEtalonsGSI,useFileRecognitionGSI;
bool AllFileGSI,AllFileEtalon,AdptiveThreshold,useParametrs;

int bands,Dimension,NumberPixels;
int N,AmtLines,AmtColumns;
int ColumnMin,ColumnMax,LineMin,LineMax;
int EtalonMin,EtalonMax;
float Percent,FixedThreshold;
int *IPint,*Etint;
int ItemInitialPoints,ItemEtalonsGSI,ItemInvariant;
int TypeInitialPoints,TypeEtalonsGSI,TypeInvariant;
long LengthFileInitialPoints,LengthFileEtalonsGSI,LengthInitialPoints;
long LengthLine,LengthLineMin,LengthLineMax,LengthEtalonsMin,
     AmtLineBegin,AmtLineEnd;
long SizeLine,SizeLineMin,SizeLineMax,SizeEtalonsMin;
long SizeFileInitialPoints,SizeFileEtalonsGSI,SizeFileRecognitionGSI;
long SizeInitialPoints;
long Len,Adr,Adz,*IPl,*Etl;

short *IPsh,*Etsh,*Ptr,*Psv;
float *IPf,*Etf;
double dZd,Zt,*IPd,*Etd,*ZId,*ZEtd,*MetrEtals;
long double *IPld,*Etld;
__int8 *IPi8,*Eti8;
__int64 *IPi64,*Eti64;
int i,j,jt,il,k,Mk,Mkn,Mkb,kL,kLine,kC,kLC,FileRecAcc,MarkClass;
char *Pch;
union {long l; float f;} lf;

int NumEtal,CurEtal,OptEtal;
double SE,Mx,Dx,Mxx,Mxy,cov,Er,Err,Erm,Re,Rm,Por=0.975,Emin,Emax;
struct EtalonsGSI { double Mx; double Dx; double Mxx;
                    double PRe; double Thr;} *DataEtal;
long Ade;
__int8 *BitMap;
//---------------------------------------------------------------------------
__fastcall TFormImagePixelPlus::TFormImagePixelPlus(TComponent* Owner)
        : TForm(Owner)
  {
  strcpy(Path,ParamStr(0).c_str());
  *strrchr(Path,'\\')='\0';
  strcpy(CurrentDirectory,Path);
  useFileInitialPoints=false;
  useFileEtalonsGSI=false;
  useParametrs=false;
 
  Execute->Enabled=false;
  if(RadioGroupAmtPixel->ItemIndex==0)
    {  GroupBoxOptionsFragment->Visible=false;
    }
  else
    { GroupBoxOptionsFragment->Visible=true;
    EditLineMax->Text= EditAmtLines->Text;
    EditColumnMax->Text=EditAmtColumns->Text;
    }
  if(RadioGroupThreshold->ItemIndex==0)
    { EditThreshold->Visible=false;
    EditPercent->Visible=true;
    }
  else
    { EditThreshold->Visible=true;
    EditPercent->Visible=false;
    }
  if(RadioGroupVolumeEtalons->ItemIndex==0)
    { PanelNumEtalons->Visible=false;
    }
  else PanelNumEtalons->Visible=true;
  }
//---------------------------------------------------------------------------
void __fastcall TFormImagePixelPlus::inFileInitialPointsClick(TObject *Sender)
  {
  OpenDialogFileInitialPoints->InitialDir=(AnsiString)CurrentDirectory;
  OpenDialogFileInitialPoints->Title="�������� ��������� ����� GSD";
  if(OpenDialogFileInitialPoints->Execute())
    { strcpy(NameFileInitialPoints,OpenDialogFileInitialPoints->FileName.c_str());
    }
  else
    {
    strcpy(text,"�� ������ ���� InitialPoints");
    MessageBox(0,text,"��������� �����",MB_OK);
    return;
    }
  HederFileInitialPoints=open(NameFileInitialPoints,O_BINARY|O_RDWR);

  if(HederFileInitialPoints<1)
    { useFileInitialPoints=false;
    strcpy(text,"�� ������ �������� ���� InitialPoints");
    MessageBox(0,text,"��������� �����",MB_OK);
    return;
    }
  SizeFileInitialPoints=filelength(HederFileInitialPoints);

  strcpy(CurrentDirectory,NameFileInitialPoints);
  *strrchr(CurrentDirectory,'\\')='\0';
  useFileInitialPoints=true;

  if(useParametrs&useFileEtalonsGSI==true) Execute->Enabled=true;
  return;
  }

//---------------------------------------------------------------------------
void __fastcall TFormImagePixelPlus::inEtalonsFileClick(TObject *Sender)
  {
  OpenDialogFileEtalonsGSI->InitialDir=(AnsiString)CurrentDirectory;
  OpenDialogFileEtalonsGSI->Title="�������� ����� Etalons ";
  if(OpenDialogFileEtalonsGSI->Execute())
    { strcpy(NameFileEtalonsGSI,OpenDialogFileEtalonsGSI->FileName.c_str());
    }
  else
    {
    strcpy(text,"�� ������ ���� EtalonsGSI");
    MessageBox(0,text,"��������� �����",MB_OK);
    }

  HederFileEtalonsGSI=open(NameFileEtalonsGSI,O_BINARY|O_RDWR);

  if(HederFileEtalonsGSI<1)
    { useFileEtalonsGSI=false;
    strcpy(text,"�� ������ ���� EtalonsGSI");
    MessageBox(0,text,"��������� �����",MB_OK);
    return;
    }
  SizeFileEtalonsGSI=filelength(HederFileEtalonsGSI);

  strcpy(CurrentDirectory,NameFileEtalonsGSI);
  *strrchr(CurrentDirectory,'\\')='\0';
  useFileEtalonsGSI=true;

  if(useFileInitialPoints&useParametrs==true) Execute->Enabled=true;
  return;
  }

//---------------------------------------------------------------------------
void __fastcall TFormImagePixelPlus::outRecognizeFileClick(
      TObject *Sender)
  {
  SaveDialogFileRecognitionGSI->InitialDir=(AnsiString)CurrentDirectory;
  SaveDialogFileRecognitionGSI->Title="������ ����� ������������� � ������� RAW";
  if(SaveDialogFileRecognitionGSI->Execute())
    { strcpy(NameFileRecognitionGSI,SaveDialogFileRecognitionGSI->FileName.c_str());
    }
  else
    {
    strcpy(text,"�� ������ ���� ��� ������ RecognitionGSI");
    MessageBox(0,text,"��������� �����",MB_OK);
    }
  FileRecAcc=0;
  if(access(NameFileRecognitionGSI,0)==0)
    {
    sprintf(text,"*.gsd* - ���� %s ��� ����������",NameFileRecognitionGSI);
    j=MessageBox(0,text,"������������ ���� ???",MB_YESNO);
    if(j==IDYES)
      { unlink(NameFileRecognitionGSI);
      HederFileRecognitionGSI=open(NameFileRecognitionGSI,O_CREAT|O_RDWR|O_BINARY,S_IWRITE);
      }
    else
      {
      jt=MessageBox(0,text,"�������� � ���� ???",MB_YESNO);
      if(jt==IDYES)
        { FileRecAcc=1;
        HederFileRecognitionGSI=open(NameFileRecognitionGSI,O_BINARY|O_RDWR);
        }
      else  return;
      }
    }
  else HederFileRecognitionGSI=open(NameFileRecognitionGSI,O_CREAT|O_RDWR|O_BINARY,S_IWRITE);

  if(HederFileRecognitionGSI<1)
    { useFileRecognitionGSI=false;
    strcpy(text,"�� ������ ��� ������ ���� FileRecognitionGSI");
    MessageBox(0,text,"��������� �����",MB_OK);
    return;
    }

  strcpy(CurrentDirectory,NameFileRecognitionGSI);
  *strrchr(CurrentDirectory,'\\')='\0';
  useFileRecognitionGSI=true;

  return;
  }
//---------------------------------------------------------------------------

void __fastcall TFormImagePixelPlus::ExecuteClick(TObject *Sender)
  {
  if(useFileInitialPoints==false) return;
  if(useFileEtalonsGSI==false) return;
  if(useParametrs==false) return;

  strcpy(NameFileText,NameFileInitialPoints);
  Pch=strchr(NameFileText,'.');
  if(Pch!=NULL) *Pch='\0';
  strcat(NameFileText,".txt");
  HederProtokol= fopen(NameFileText, "a+t");
  if(HederProtokol!=NULL)
    { fprintf(HederProtokol,
        "\n\n  �������� ������ ��������� ������������� �������� GSI");
    fprintf(HederProtokol,
        "\n                == RecognitionGSI == ");
    fprintf(HederProtokol,
        "\n == ���������� ������������� ��������  %s == , \n == �� ���� ��������  %s == ",
        NameFileInitialPoints,NameFileEtalonsGSI);
//    fprintf(HederProtokol,"\n == ������ �������������� �������� == ");
    }
  N=Dimension;
  NumberPixels=0;

  switch(ItemInitialPoints)
    {
    case 0: TypeInitialPoints=1;  break;
    case 1: TypeInitialPoints=2;  break;
    case 2: TypeInitialPoints=4;  break;
    case 3: TypeInitialPoints=4;  break;
    case 4: TypeInitialPoints=8;  break;
    case 5: TypeInitialPoints=4;  break;
    case 6: TypeInitialPoints=8;  break;
    case 7: TypeInitialPoints=10; break;
    default: strcpy(text,"�� ��������� ��� InitialPoints");
             MessageBox(0,text,"���������� ������",MB_OK);
             Close();
    }

  LengthFileInitialPoints=SizeFileInitialPoints/TypeInitialPoints;
  NumberPixels=LengthFileInitialPoints/Dimension;
  k=AmtColumns*AmtLines;
  if(NumberPixels!=k)
    { strcpy(text,"������ � ������� ���������� ���");
    MessageBox(0,text,"���������� ������",MB_OK);
    Close();
    }
  if(AllFileGSI==true)
    { LineMin=1;
    LineMax=AmtLines;
    }
  ZId=new double [Dimension];
  ZEtd=new double [Dimension];
  if(ZId==NULL||ZEtd==NULL)
    { strcpy(text,"��� ������ ��� �������� ZId||ZEtd");
    MessageBox(0,text,"���������� ������",MB_OK);
    Close();
    }
  LengthLine=AmtColumns*Dimension;
  SizeLine=LengthLine*TypeInitialPoints;
  IPd=new double [SizeLine/8+1];
  AmtLineBegin=(LineMin-1)*AmtColumns;
  LengthLineMin=AmtLineBegin*Dimension;
  SizeLineMin=LengthLineMin*TypeInitialPoints;
  AmtLineEnd=LineMax*AmtColumns;
  LengthLineMax=AmtLineEnd*Dimension;
  SizeLineMax=LengthLineMax*TypeInitialPoints;

  switch(ItemInitialPoints)
    {
    case 0:  IPi8=(__int8 *)(&IPd[0]); break;
    case 1:  IPsh=(short *)(&IPd[0]); break;
    case 2:  IPint=(int *)(&IPd[0]);break;
    case 3:  IPl=(long *)(&IPd[0]); break;
    case 4:  IPi64=(__int64 *)(&IPd[0]); break;
    case 5:  IPf=(float *)(&IPd[0]);  break;
    case 6:  IPd=(double *)(&IPd[0]);  break;
    case 7:  IPld=(long double *)(&IPd[0]); break;
    default: strcpy(text,"�� ��������� ��� InitialPoints");
             MessageBox(0,text,"���������� ������",MB_OK);
             Close();
    }

  switch(ItemEtalonsGSI)
    {
    case 0: TypeEtalonsGSI=1;  break;
    case 1: TypeEtalonsGSI=2;  break;
    case 2: TypeEtalonsGSI=4;  break;
    case 3: TypeEtalonsGSI=4;  break;
    case 4: TypeEtalonsGSI=8;  break;
    case 5: TypeEtalonsGSI=4;  break;
    case 6: TypeEtalonsGSI=8;  break;
    case 7: TypeEtalonsGSI=10; break;
    default: strcpy(text,"�� ��������� ��� EtalonsGSI");
             MessageBox(0,text,"���������� ������",MB_OK);
             Close();
    }
  LengthFileEtalonsGSI=SizeFileEtalonsGSI/TypeEtalonsGSI;
  if(AllFileEtalon==true)
    { EtalonMax=LengthFileEtalonsGSI/Dimension;
    NumEtal=EtalonMax+1-EtalonMin;
    Etd=new double [SizeFileEtalonsGSI/8+1];
    LengthEtalonsMin=0;
    SizeEtalonsMin=0;
    }
  else
    { NumEtal=EtalonMax+1-EtalonMin;
    LengthFileEtalonsGSI=NumEtal*Dimension;
    SizeFileEtalonsGSI=LengthFileEtalonsGSI*TypeEtalonsGSI;
    LengthEtalonsMin=(EtalonMin-1)*Dimension;
    SizeEtalonsMin=LengthEtalonsMin*TypeEtalonsGSI;
    Etd=new double [SizeFileEtalonsGSI/8+1];
    }

  switch(ItemEtalonsGSI)
    {
    case 0:   Eti8=(__int8 *)(&Etd[0]); break;
    case 1:   Etsh=(short *)(&Etd[0]); break;
    case 2:   Etint=(int *)(&Etd[0]); break;
    case 3:   Etl=(long *)(&Etd[0]); break;
    case 4:   Eti64=(__int64 *)(&Etd[0]); break;
    case 5:   Etf=(float *)(&Etd[0]); break;
    case 6:   Etd=(double *)(&Etd[0]); break;
    case 7:   Etld=(long double *)(&Etd[0]); break;
    default: strcpy(text,"�� ��������� ��� EtalonsGSI");
             MessageBox(0,text,"���������� ������",MB_OK);
             Close();
    }

  if(IPd==NULL||Etd==NULL)
    {
    strcpy(text,"��� ������ ��� ������� IPd|Etd");
    MessageBox(0,text,"��������� �����",MB_OK);
    return;
    }

  lseek(HederFileEtalonsGSI,SizeEtalonsMin,SEEK_SET);
  Len=read(HederFileEtalonsGSI,Etd,SizeFileEtalonsGSI);
  if(Len!=SizeFileEtalonsGSI)
    {
    strcpy(text,"������ ������ ����� EtalonsGSI");
    MessageBox(0,text,"��������� �����",MB_OK);
    return;
    }

  SizeFileRecognitionGSI=SizeFileInitialPoints/TypeInitialPoints;
  SizeFileRecognitionGSI/=Dimension;
  BitMap=new __int8 [SizeFileRecognitionGSI];

  MetrEtals=new double [LengthFileEtalonsGSI];
  DataEtal=new struct EtalonsGSI[NumEtal];

  if(BitMap==NULL||DataEtal==NULL||MetrEtals==NULL)
    {
    strcpy(text,"��� ������ ��� ������� BitMap|DataEtal|MetrEtals");
    MessageBox(0,text,"��������� �����",MB_OK);
    return;
    }
  if(FileRecAcc==0)
    { for(i=0; i<NumberPixels; i++) BitMap[i]=255;
    }
   else
     {
     lseek(HederFileRecognitionGSI,0l,SEEK_SET);
     Len=read(HederFileRecognitionGSI,BitMap,SizeFileRecognitionGSI);
     if(Len!=SizeFileRecognitionGSI)
       {
       strcpy(text,"������ ������ ����� BitMap");
       MessageBox(0,text,"��������� �����",MB_OK);
       return;
       }
     }

  Ade=0;
  for(CurEtal=0; CurEtal<NumEtal; CurEtal++)
    {
    switch(ItemEtalonsGSI)
      {
      case 0: for(i=0; i<N; i++) ZEtd[i]=Eti8[Ade+i]; break;
      case 1: for(i=0; i<N; i++) ZEtd[i]=Etsh[Ade+i]; break;
      case 2: for(i=0; i<N; i++) ZEtd[i]=Etint[Ade+i]; break;
      case 3: for(i=0; i<N; i++) ZEtd[i]=Etl[Ade+i]; break;
      case 4: for(i=0; i<N; i++) ZEtd[i]=Eti64[Ade+i]; break;
      case 5: for(i=0; i<N; i++) ZEtd[i]=Etf[Ade+i]; break;
      case 6: for(i=0; i<N; i++) ZEtd[i]=Etd[Ade+i]; break;
      case 7: for(i=0; i<N; i++) ZEtd[i]=Etld[Ade+i]; break;
      default: strcpy(text,"�������� ��� InitialPoints");
               MessageBox(0,text,"���������� ������",MB_OK);
               Close();
      }

    Mx=0.; Dx=0;
    for(j=0; j<N; j++)
      {
      Mx+=ZEtd[j]; Dx+=ZEtd[j]*ZEtd[j];
      }
    Mx/=N; Dx/=N;  Mxx=Dx;
    Dx-=Mx*Mx;
 
    DataEtal[CurEtal].Mx=Mx;
    DataEtal[CurEtal].Dx=Dx;
    DataEtal[CurEtal].Mxx=Mxx;
    DataEtal[CurEtal].PRe=Mxx/10000.*Percent*Percent;
    if(AdptiveThreshold==true)
      { DataEtal[CurEtal].Thr= DataEtal[CurEtal].PRe;
      }
    else  DataEtal[CurEtal].Thr=FixedThreshold;
    for(j=0; j<N; j++)
      { MetrEtals[Ade+j]= ZEtd[j]-Mx;
      }
    Ade+=Dimension;
    }

  Adr=0;  Adz=0; Mk=0; Mkn=0; Mkb=0;
  kLine=LineMax+1-LineMin;
  lseek(HederFileInitialPoints,SizeLineMin,SEEK_SET);
  for(kL=0; kL<kLine; kL++)
    {
    Len=read(HederFileInitialPoints,IPd,SizeLine);
    if(Len!=SizeLine)
      {
      strcpy(text,"������ ������ ������ GSI");
      MessageBox(0,text,"��������� �����",MB_OK);
      return;
      }
    kLC=(LineMin+kL-1)*AmtColumns;
    for(kC=ColumnMin; kC<=ColumnMax; kC++)
      {
      k=kLC+kC-1;
      Adr=(kC-1)*Dimension;
      switch(ItemInitialPoints)
        {
        case 0: for(i=0; i<N; i++) ZId[i]=IPi8[Adr+i]; break;
        case 1: for(i=0; i<N; i++) ZId[i]=IPsh[Adr+i]; break;
        case 2: for(i=0; i<N; i++) ZId[i]=IPint[Adr+i]; break;
        case 3: for(i=0; i<N; i++) ZId[i]=IPl[Adr+i]; break;
        case 4: for(i=0; i<N; i++) ZId[i]=IPi64[Adr+i]; break;
        case 5: for(i=0; i<N; i++) ZId[i]=IPf[Adr+i]; break;
        case 6: for(i=0; i<N; i++) ZId[i]=IPd[Adr+i]; break;
        case 7: for(i=0; i<N; i++) ZId[i]=IPld[Adr+i]; break;
        default: strcpy(text,"�������� ��� InitialPoints");
                 MessageBox(0,text,"���������� ������",MB_OK);
                 Close();
        }
      if(ZId[0]<0) { Mkb++; BitMap[k]=0; continue;}
      Mx=0.; Dx=0;
      for(j=0; j<N; j++)
        {
        Mx+=ZId[j]; Dx+=ZId[j]*ZId[j];
        }
      Mx/=N; Dx/=N;   Mxx=Dx;
      Dx-=Mx*Mx;
      if(Dx<=0)  { Mkb++; continue;}

      Ade=0;
      Erm=Dx;  Rm=0;   OptEtal=-1;
      for(CurEtal=0; CurEtal<NumEtal; CurEtal++)
        {  cov=0.;
        for(j=0; j<N; j++)  cov+=ZId[j]*MetrEtals[Ade+j];
        cov/=N;

        if(ItemInvariant==0)
          { Mxy=cov+DataEtal[CurEtal].Mx*Mx;
          Er=DataEtal[CurEtal].Mxx+Mxx-2*Mxy;
          }
        else
          {
          if(ItemInvariant==1)
            { Mxy=cov+DataEtal[CurEtal].Mx*Mx;
            Er=DataEtal[CurEtal].Mxx-(Mxy/Mxx)*Mxy;
            //Er=Mxx-(Mxy/DataEtal[CurEtal].Mxx)*Mxy;
            }
          else
            {
            if(ItemInvariant==2)
              { Er=DataEtal[CurEtal].Dx+Dx-2*cov;
              // Er=2.*(SE-cov/DataEtal[CurEtal].Scale/Scale);
              }
            else
              { Er=DataEtal[CurEtal].Dx-(cov/Dx)*cov;
              //Er=SE*(1.-cov*cov/(Dx*DataEtal[CurEtal].Dx));
              }
            }
          }
        if(Erm>Er) { Erm=Er; OptEtal=CurEtal;}
        Ade+=Dimension;
        }
      if(Erm<DataEtal[OptEtal].Thr&&OptEtal>=0)
        {
        BitMap[k]=MarkClass; Mk++;
        }
       else   Mkn++;
      }
    }

  if(HederProtokol!=NULL)
     {
    fprintf(HederProtokol,"\n MKall=%8i, MKnorm=%8i, MKbed=%8i, MKrec=%8i ",
                    NumberPixels,Mkn,Mkb,Mk);
      }

  if(useFileRecognitionGSI==true)
    {
    lseek(HederFileRecognitionGSI,0l,SEEK_SET);
    Len=write(HederFileRecognitionGSI,BitMap,SizeFileRecognitionGSI);
    if(Len!=SizeFileRecognitionGSI)
      {
      strcpy(text,"������ ������ ����� BitMap");
      MessageBox(0,text,"��������� �����",MB_OK);
      return;
      }
    }

  Execute->Enabled=false;
  return;
  }
//---------------------------------------------------------------------------
void __fastcall TFormImagePixelPlus::ExitClick(TObject *Sender)
  {
  Execute->Enabled=true;
  Close();
  }
//---------------------------------------------------------------------------
void __fastcall TFormImagePixelPlus::ButtonChangeDataClick(TObject *Sender)
  {
   if(RadioGroupAmtPixel->ItemIndex==0)
     { AllFileGSI=true;
     LineMin=1;
     LineMax=atoi(EditAmtLines->Text.c_str());
     ColumnMin=1;
     ColumnMax=atoi(EditAmtColumns->Text.c_str());
     }
   else
    { AllFileGSI=false;
    LineMin=atoi(EditLineMin->Text.c_str());
    LineMax=atoi(EditLineMax->Text.c_str());
    ColumnMin=atoi(EditColumnMin->Text.c_str());
    ColumnMax=atoi(EditColumnMax->Text.c_str());
    }

  Dimension=atoi(EditDimension->Text.c_str());
  ItemInitialPoints=ComboBoxTypeInitialPoints->ItemIndex;
  AmtLines=atoi(EditAmtLines->Text.c_str());
  AmtColumns=atoi(EditAmtColumns->Text.c_str());

  ItemEtalonsGSI=ComboBoxTypeEtalonsGSI->ItemIndex;
  if(RadioGroupVolumeEtalons->ItemIndex==0)
    { AllFileEtalon=true;
    EtalonMin=1;
    EtalonMax=1;
    }
  else
   { AllFileEtalon=false;
   EtalonMin=atoi(EditMinEtalon->Text.c_str());
   EtalonMax=atoi(EditMaxEtalon->Text.c_str());
   }

  ItemInvariant=ComboBoxChooseSimelirety->ItemIndex;
  if(RadioGroupThreshold->ItemIndex==0)
    { AdptiveThreshold=true;
    Percent=atof(EditPercent->Text.c_str());
    FixedThreshold=0;
    }
   else
    { AdptiveThreshold=false;
    Percent=0;
    FixedThreshold=atof(EditThreshold->Text.c_str());
    }
  MarkClass=atoi(EditMarkClass->Text.c_str());

  useParametrs=true;
  if(useFileInitialPoints&useFileEtalonsGSI==true) Execute->Enabled=true;

  return;
  }
//---------------------------------------------------------------------------

void __fastcall TFormImagePixelPlus::RadioGroupAmtPixelClick(
      TObject *Sender)
  {
  if(RadioGroupAmtPixel->ItemIndex==0)
    {  GroupBoxOptionsFragment->Visible=false;
    }
  else
    {
    GroupBoxOptionsFragment->Visible=true;
    EditLineMax->Text= EditAmtLines->Text;
    EditColumnMax->Text=EditAmtColumns->Text;
    }
  }
//---------------------------------------------------------------------------

void __fastcall TFormImagePixelPlus::RadioGroupVolumeEtalonsClick(
      TObject *Sender)
  {
  if(RadioGroupVolumeEtalons->ItemIndex==0)
    { PanelNumEtalons->Visible=false;
    }
  else PanelNumEtalons->Visible=true;
  }
//---------------------------------------------------------------------------


void __fastcall TFormImagePixelPlus::RadioGroupThresholdClick(
      TObject *Sender)
  {
   if(RadioGroupThreshold->ItemIndex==0)
    { EditThreshold->Visible=false;
    EditPercent->Visible=true;
    }
  else
    { EditThreshold->Visible=true;
    EditPercent->Visible=false;
    }
  }
//---------------------------------------------------------------------------

