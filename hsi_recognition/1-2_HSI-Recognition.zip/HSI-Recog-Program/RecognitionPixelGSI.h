//---------------------------------------------------------------------------

#ifndef RecognitionPixelGSIH
#define RecognitionPixelGSIH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Menus.hpp>
#include <Dialogs.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TFormImagePixelPlus : public TForm
{
__published:	// IDE-managed Components
        TMainMenu *MainMenu1;
        TMenuItem *FileGSDinVF;
        TMenuItem *inFileInitialPoints;
        TMenuItem *Execute;
        TMenuItem *Exit;
        TOpenDialog *OpenDialogFileInitialPoints;
        TButton *ButtonChangeData;
        TMenuItem *outRecognizeFile;
        TSaveDialog *SaveDialogFileRecognitionGSI;
        TOpenDialog *OpenDialogFileEtalonsGSI;
        TMenuItem *inEtalonsFile;
        TRadioGroup *RadioGroupAmtPixel;
        TGroupBox *GroupBoxOptionsFile;
        TLabel *LabelDimension;
        TLabel *LabelAmtLines;
        TLabel *LabelInitialPoints;
        TEdit *EditAmtLines;
        TEdit *EditDimension;
        TComboBox *ComboBoxTypeInitialPoints;
        TLabel *LabelAmtColumns;
        TEdit *EditAmtColumns;
        TGroupBox *GroupBoxOptionsFragment;
        TLabel *LabelLine;
        TLabel *LabelColumn;
        TEdit *EditColumnMin;
        TEdit *EditColumnMax;
        TEdit *EditLineMin;
        TEdit *EditLineMax;
        TLabel *LabelNimMax;
        TGroupBox *GroupBoxRecognition;
        TLabel *LabelChooseSimilarity;
        TComboBox *ComboBoxChooseSimelirety;
        TRadioGroup *RadioGroupThreshold;
        TEdit *EditPercent;
        TEdit *EditThreshold;
        TGroupBox *GroupBoxalons;
        TLabel *LabelFilteringPoints;
        TComboBox *ComboBoxTypeEtalonsGSI;
        TRadioGroup *RadioGroupVolumeEtalons;
        TPanel *PanelNumEtalons;
        TLabel *LabelFrom;
        TEdit *EditMinEtalon;
        TLabel *LabelTo;
        TEdit *EditMaxEtalon;
        TLabel *LabelMarkClass;
        TEdit *EditMarkClass;
        void __fastcall inFileInitialPointsClick(TObject *Sender);
        void __fastcall ExecuteClick(TObject *Sender);
        void __fastcall ExitClick(TObject *Sender);
        void __fastcall ButtonChangeDataClick(TObject *Sender);
        void __fastcall outRecognizeFileClick(TObject *Sender);
        void __fastcall inEtalonsFileClick(TObject *Sender);
        void __fastcall RadioGroupAmtPixelClick(TObject *Sender);
        void __fastcall RadioGroupVolumeEtalonsClick(TObject *Sender);
        void __fastcall RadioGroupThresholdClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
        __fastcall TFormImagePixelPlus(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TFormImagePixelPlus *FormImagePixelPlus;
//---------------------------------------------------------------------------
#endif
