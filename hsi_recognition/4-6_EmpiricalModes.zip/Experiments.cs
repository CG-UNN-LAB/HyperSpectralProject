void Main()
{
	string expOutputPath = PLACE_PATH_TO_OUTPUT_DIRECTORY_HERE;

	List<MaterialInfo> materials = new List<MaterialInfo>();
	materials.Add(new MaterialInfo("5 water", new Point(315, 775), GetPixelNumber(new Point(315, 775), MyExtensions.rasterXSize), new int[MyExtensions.rasterLayers], new double[MyExtensions.rasterPixels]));
	materials.Add(new MaterialInfo("6 ground", new Point(540, 630), GetPixelNumber(new Point(540, 630), MyExtensions.rasterXSize), new int[MyExtensions.rasterLayers], new double[MyExtensions.rasterPixels]));
	materials.Add(new MaterialInfo("4 ocean", new Point(209, 470), GetPixelNumber(new Point(209, 470), MyExtensions.rasterXSize), new int[MyExtensions.rasterLayers], new double[MyExtensions.rasterPixels]));
	materials.Add(new MaterialInfo("3 material_447_1275", new Point(447, 1275), GetPixelNumber(new Point(447, 1275), MyExtensions.rasterXSize), new int[MyExtensions.rasterLayers], new double[MyExtensions.rasterPixels]));
	materials.Add(new MaterialInfo("2 material_442_1332", new Point(442, 1332), GetPixelNumber(new Point(442, 1332), MyExtensions.rasterXSize), new int[MyExtensions.rasterLayers], new double[MyExtensions.rasterPixels]));
	materials.Add(new MaterialInfo("1 material_426_1351", new Point(426, 1351), GetPixelNumber(new Point(426, 1351), MyExtensions.rasterXSize), new int[MyExtensions.rasterLayers], new double[MyExtensions.rasterPixels]));

	foreach (MaterialInfo material in materials)
	{
		Buffer.BlockCopy(MyExtensions.sourceDatasetEx, MyExtensions.rasterLayers * MyExtensions.intSize * material.MaterialIndex, material.MaterialSample, 0, MyExtensions.rasterLayers * MyExtensions.intSize);
		material.MaterialAvg = material.MaterialSample.Average();
		material.MaterialBottomLeft = material.MaterialSample.Sum(item => Math.Pow(item - material.MaterialAvg, 2.0));
		material.MaterialSpectrNorm = material.MaterialSample.Select(item => item - material.MaterialAvg).ToArray();
	}

	double[] steps = new double[] { 0.9999, 0.999, 0.99, 0.9 };

	//Заголовок файла значений корреляции по одному материалу.
	//File.WriteAllText(Path.Combine(expOutputPath, "EmpiricalModeCorrelation.tsv"), String.Join("\t", "Номер моды", String.Join("\t", Enumerable.Range(0, 21))));
	foreach (MaterialInfo material in materials)
	{
		double[][] signals = null;
		double[][] rSamples = null;
		material.EmpModes = MyExtensions.GetEmpericalModes(material.MaterialSample, out signals, out rSamples);

		//Запись значений всех мод по каждому материалу в соответствующий файл.
		//File.WriteAllLines(Path.Combine(expOutputPath, $"{material.MaterialName} - modes.tsv"), material.EmpModes.Select(item => String.Join("\t", item)));

		double[] corrsModes = new double[material.EmpModes.Length];
		double[] corrsWithSample = new double[material.EmpModes.Length];
		corrsWithSample[0] = MyExtensions.GetPearsonCorrelation(material.MaterialSample.Select(item => item * 1.0).ToArray(), material.EmpModes[0]);

		for (int empMode = 1; empMode < material.EmpModes.Length; empMode++)
		{
			corrsModes[empMode] = MyExtensions.GetPearsonCorrelation(material.EmpModes[empMode - 1], material.EmpModes[empMode]);
			corrsWithSample[empMode] = MyExtensions.GetPearsonCorrelation(material.MaterialSample.Select(item => item * 1.0).ToArray(), material.EmpModes[empMode]);
		}

		//Запись в файл значений корреляции по одному материалу.
		//File.AppendAllText(Path.Combine(expOutputPath, "EmpiricalModeCorrelation.tsv"), String.Join("\t", "\n" + material.MaterialName + " сигнатура с модами", String.Join("\t", corrsWithSample)));
		//File.AppendAllText(Path.Combine(expOutputPath, "EmpiricalModeCorrelation.tsv"), String.Join("\t", "\n" + material.MaterialName + " моды между собой", String.Join("\t", corrsModes)));
	}

	List<string> resCors = new List<string>();

	resCors.Add($"Сигнатуры");
	resCors.Add(String.Join("\t", String.Empty, String.Join("\t", materials.Select(item => item.MaterialName))));
	foreach (MaterialInfo materialX in materials)
	{
		List<double> corrLine = new List<double>();
		foreach (MaterialInfo materialY in materials)
		{
			corrLine.Add(MyExtensions.GetPearsonCorrelation(materialX.MaterialSample.Select(item => item * 1.0).ToArray(), materialY.MaterialSample.Select(item => item * 1.0).ToArray()));
		}
		resCors.Add(String.Join("\t", materialX.MaterialName, String.Join("\t", corrLine)));
	}
	resCors.Add(String.Empty);

	for (int empMode = 0; empMode < 17; empMode++)
	{
		resCors.Add($"Мода номер {empMode + 1}");
		resCors.Add(String.Join("\t", String.Empty, String.Join("\t", materials.Select(item => item.MaterialName))));
		foreach (MaterialInfo materialX in materials)
		{
			List<double> corrLine = new List<double>();
			foreach (MaterialInfo materialY in materials)
			{
				corrLine.Add(MyExtensions.GetPearsonCorrelation(materialX.EmpModes[empMode], materialY.EmpModes[empMode]));
			}
			resCors.Add(String.Join("\t", materialX.MaterialName, String.Join("\t", corrLine)));
		}
		resCors.Add(String.Empty);

	}

	//Запись в файл значений корреляции между материалами.
	//File.WriteAllLines(Path.Combine(expOutputPath, "EmpiricalModeCorrelationRes.tsv"), resCors);

	List<string> statFeatures = new List<string>();

	statFeatures.Add($"Статистические характеристики");
	statFeatures.Add(String.Join("\t", String.Empty, String.Join("\t", new string[] { "Минимум", "Максимум", "Среднее арифметическое", "Среднеквадратическое отклонение" })));
	foreach (MaterialInfo material in materials)
	{
		double[] agregatedEmpMode = new double[MyExtensions.rasterLayers];

		for (int i = 0; i < agregatedEmpMode.Length; i++)
		{
			agregatedEmpMode[i] += material.EmpModes[0][i] + material.EmpModes[1][i] + material.EmpModes[2][i];
		}

		statFeatures.Add(String.Join("\t", material.MaterialName, String.Join("\t", new object[] { agregatedEmpMode.Min(), agregatedEmpMode.Max(), agregatedEmpMode.Average(), Math.Sqrt(agregatedEmpMode.Sum(item => Math.Pow(item - agregatedEmpMode.Average(), 2.0) / MyExtensions.rasterLayers)) })));
	}

	//Запись в файл значений корреляции между материалами.
	//File.WriteAllLines(Path.Combine(expOutputPath, "StatFeatures.tsv"), statFeatures);

	//Запустить прототип процедуры распознавания на GPU.
	//RunCalc(materials, steps);
}

public static void RunCalc(List<MaterialInfo> materials, double[] steps)
{
	using (Context context = new Context())
	{
		using (CudaAccelerator accelerator = new CudaAccelerator(context))
		{
			Action<Index, ArrayView<double>, double, ArrayView2D<int>, ArrayView<double>> loadedKernel = accelerator.LoadAutoGroupedStreamKernel<Index, ArrayView<double>, double, ArrayView2D<int>, ArrayView<double>>(PearsonCorrelationKernel);

			using (MemoryBuffer<double> targetSample = accelerator.Allocate<double>(MyExtensions.rasterLayers))
			using (MemoryBuffer2D<int> signatures = accelerator.Allocate<int>(MyExtensions.rasterPixels, MyExtensions.rasterLayers))
			using (MemoryBuffer<double> correlationSample = accelerator.Allocate<double>(MyExtensions.rasterPixels))
			{
				signatures.CopyFrom(MyExtensions.sourceDatasetEx, new Index2(), new Index2(), new Index2(MyExtensions.rasterPixels, MyExtensions.rasterLayers));

				foreach (MaterialInfo material in materials)
				{
					targetSample.CopyFrom(material.MaterialSpectrNorm, 0, 0, MyExtensions.rasterLayers);
					loadedKernel(MyExtensions.rasterPixels, targetSample.View, material.MaterialBottomLeft, signatures.View, correlationSample.View);
					accelerator.Synchronize();
					correlationSample.CopyTo(material.MaterialCorrelation, 0, 0, MyExtensions.rasterPixels);
				}
			}
		}
	}
}

public static int GetPixelNumber(Point pixel, int xSize)
{
	return xSize * pixel.Y + pixel.X;
}

public static void PearsonCorrelationKernel(Index index, ArrayView<double> targetSample, double bottomLeft, ArrayView2D<int> signatures, ArrayView<double> correlationValues)
{
	int layers = 224;

	double yAvg = 0.0;
	for (int i = 0; i < layers; i++)
	{
		yAvg += signatures[index, i];
	}
	yAvg = yAvg / layers;

	double top = 0.0f;
	double bottomRight = 0.0;

	double topRightMult = 0.0;

	for (int i = 0; i < layers; i++)
	{
		topRightMult = signatures[index, i] - yAvg;
		top += targetSample[i] * topRightMult;

		bottomRight += topRightMult * topRightMult;
	}

	if (bottomRight == 0.0)
		correlationValues[index] = 0.0;
	else
		correlationValues[index] = top / Math.Sqrt(bottomLeft * bottomRight);
}

public class MaterialInfo
{
	public string MaterialName { get; set; }
	public Point MaterialPixel { get; set; }
	public int MaterialIndex { get; set; }
	public int[] MaterialSample { get; set; }
	public double[] MaterialCorrelation { get; set; }
	public double MaterialAvg { get; set; }
	public double MaterialBottomLeft { get; set; }
	public double[] MaterialSpectrNorm { get; set; }
	public double[][] EmpModes { get; set; }

	public MaterialInfo(string name, Point pixel, int index, int[] sample, double[] corr2)
	{
		MaterialName = name;
		MaterialPixel = pixel;
		MaterialIndex = index;
		MaterialSample = sample;
		MaterialCorrelation = corr2;
	}
}