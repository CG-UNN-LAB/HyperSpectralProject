void Main()
{
}

public static class MyExtensions
{
	public static class GdalConfiguration
	{
		private static volatile bool _configuredGdal;

		public static void ConfigureGdal()
		{
			if (_configuredGdal)
				return;

			Gdal.AllRegister();
			_configuredGdal = true;
		}
	}

	public static double GetPearsonCorrelation(double[] xSample, double[] ySample)
	{
		if (xSample == null || ySample == null)
			throw new NullReferenceException(nameof(GetPearsonCorrelation));

		if (ySample.All((item) => item == 0.0))
			return 0.0;

		if (xSample.SequenceEqual(ySample))
			return 1.0;

		double xAvg = xSample.Average();
		double yAvg = ySample.Average();

		double top = 0.0;
		double bottomLeft = 0.0;
		double bottomRight = 0.0;

		double topLeftMult = 0.0;
		double topRightMult = 0.0;

		for (int i = 0; i < xSample.Length; i++)
		{
			topLeftMult = xSample[i] - xAvg;
			topRightMult = ySample[i] - yAvg;
			top += topLeftMult * topRightMult;

			bottomLeft += Math.Pow(topLeftMult, 2.0);
			bottomRight += Math.Pow(topRightMult, 2.0);
		}

		return top / Math.Sqrt(bottomLeft * bottomRight);
	}

	public static double[][] GetEmpericalModes(int[] iSample, out double[][] signals, out double[][] rSamples)
	{
		signals = null;
		rSamples = null;

		if (iSample.All(el => el == 0))
			return null;

		int sampleSize = iSample.Length;
		int windowSize = 3;
		int bound = windowSize / 2;
		double windowSum = 0.0;

		double[] empModeSample = new double[sampleSize];
		double[] sample = iSample.Select(element => element * 1.0).ToArray();
		double[] rSample = new double[sampleSize];

		bool isDmax = false;
		bool isDmin = false;
		int dSize = sampleSize;
		int dMaxCount = 0;
		int dMinCount = 0;

		List<double[]> resEmpModes = new List<double[]>();
		List<double[]> resSamples = new List<double[]>();
		List<double[]> resRSamples = new List<double[]>();

		do
		{
			for (int i = 0; i < sampleSize; i++)
			{
				for (int j = 0; j < windowSize; j++)
				{
					if (i - bound + j < 0)
					{
						windowSum += sample[0];
						continue;
					}
					if (i - bound + j > sampleSize - 1)
					{
						windowSum += sample[sampleSize - 1];
						continue;
					}
					windowSum += sample[i - bound + j];
				}

				rSample[i] = windowSum / windowSize;
				empModeSample[i] = sample[i] - rSample[i];

				windowSum = 0.0;
			}

			dSize = sampleSize;
			dMaxCount = 0;
			dMinCount = 0;

			List<int> localMaxs = new List<int>();
			List<int> localMins = new List<int>();

			for (int i = 0; i < sampleSize; i++)
			{
				for (int j = 0; j < windowSize; j++)
				{
					if (i - bound + j == i || i - bound + j < 0 || i - bound + j > sampleSize - 1)
						continue;

					if (empModeSample[i] > empModeSample[i - bound + j])
					{
						if (!isDmin)
						{
							isDmax = true;
							continue;
						}
						else
						{
							isDmax = false;
							isDmin = false;
							break;
						}
					}
					if (empModeSample[i] < empModeSample[i - bound + j])
					{
						if (!isDmax)
						{
							isDmin = true;
							continue;
						}
						else
						{
							isDmax = false;
							isDmin = false;
							break;
						}
					}

					isDmax = false;
					isDmin = false;
					break;
				}

				if (isDmax)
				{
					localMaxs.Add(i + 1);
				}

				if (isDmin)
				{
					localMins.Add(i + 1);
				}

				isDmax = false;
				isDmin = false;
			}

			dMaxCount = localMaxs.Count;
			dMinCount = localMins.Count;

			int maxD = 0;
			localMaxs.Skip(1).Aggregate(localMaxs[0], (maxD1, next) =>
			 {
				 if (next - maxD1 > maxD)
					 maxD = next - maxD1;
				 return next;
			 });

			localMins.Skip(1).Aggregate(localMins[0], (minD1, next) =>
			 {
				 if (next - minD1 < maxD)
					 maxD = next - minD1;
				 return next;
			 });
			 
			dSize = maxD;
			resEmpModes.Add(empModeSample.Select(el => el).ToArray());
			resSamples.Add(sample.ToArray());
			resRSamples.Add(rSample.ToArray());

			windowSize = 2 * (dSize / 2) + 1;
			bound = windowSize / 2;

			sample = rSample;
			rSample = new double[sampleSize];
		}
		while (dMaxCount >= 2 && dMinCount >= 2);

		signals = resSamples.ToArray();
		rSamples = resRSamples.ToArray();

		return resEmpModes.ToArray();
	}


	public static int[,] sourceDatasetEx = null;

	public static int rasterXSize = 0;
	public static int rasterYSize = 0;
	public static int rasterLayers = 0;
	public static int rasterPixels = 0;

	public static int intSize = sizeof(int);

	public static string datasetPath = PLACE_PATH_TO_MOFFETT_FIELD_HERE;

	static MyExtensions()
	{
		GdalConfiguration.ConfigureGdal();
		ReadDataset();
	}

	public static void ReadDataset()
	{
		int[][] allLayers = null;

		using (Dataset sourceFile = Gdal.Open(datasetPath, Access.GA_ReadOnly))
		{
			rasterXSize = sourceFile.RasterXSize;
			rasterYSize = sourceFile.RasterYSize;
			rasterLayers = sourceFile.RasterCount;
			rasterPixels = rasterXSize * rasterYSize;

			allLayers = new int[rasterLayers][];

			for (int layer = 0; layer < rasterLayers; layer++)
			{
				int[] layerBuffer = new int[rasterPixels];
				sourceFile.GetRasterBand(layer + 1).ReadRaster(0, 0, rasterXSize, rasterYSize, layerBuffer, rasterXSize, rasterYSize, 0, 0);
				allLayers[layer] = layerBuffer;
			}
		}

		for (int layer = 0; layer < rasterLayers; layer++)
		{
			for (int pixel = 0; pixel < rasterPixels; pixel++)
			{
				if (allLayers[layer][pixel] < 0)
				{
					allLayers[layer][pixel] = 0;
				}
			}
		}

		sourceDatasetEx = new int[rasterPixels, rasterLayers];

		for (int pixel = 0; pixel < rasterPixels; pixel++)
		{
			int[] spectr = allLayers.Select(layer => layer[pixel]).ToArray();
			Buffer.BlockCopy(spectr, 0, sourceDatasetEx, rasterLayers * intSize * pixel, rasterLayers * intSize);
		}

		allLayers = null;
	}
}