# Вычисление параметров эмпирических мод сигнатур гиперспектральных изоражений
Код подготовлен для выполнения в среде [LINQPad 5](https://www.linqpad.net/)
### Используемое ГСИ
[Moffett Field](https://aviris.jpl.nasa.gov/data/free_data.html)
### Необходимые библиотеки
1. [GDAL 2.x](https://gdal.org/) и обёртки для C# [GISInternals](http://www.gisinternals.com/)
2. [ILGPU](http://www.ilgpu.net/)
### Необходимые пространства имён
1. OSGeo.GDAL
2. System.Threading.Tasks
3. ILGPU
4. ILGPU.Runtime
5. ILGPU.Runtime.Cuda

